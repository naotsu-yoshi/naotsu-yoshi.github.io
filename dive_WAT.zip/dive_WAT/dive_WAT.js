//timelineを作成
let timeline = [];
const myrandID = jsPsych.randomization.randomID(8);



// Informed consent
const informedConsentText = [
      `<br>
      <h2>本調査の参加についての同意確認</h2>
      <div align='left'>

      <ol>
      <b><li>本調査の目的と内容</li></b>
              この調査は空間的認識について調査するものです。<br>
              この調査ではいくつかの質問の後，いくつかの図形を配置してもらいます。<br>
              なお，本調査はあなた個人の性格や能力を個別に評価することを目的とはしておりません。
      <br>
      <br>
      <b><li>所要時間</li></b></li>
          回答の所要時間は<b><u>5分程度</u></b>です。
      <br>
      <br>
      <b><li>データについて</li></b>
          分析を行う際，<b>得られたデータは匿名で扱う</b>ことをお約束します。<br>
          <u>取得したデータや個人情報は研究実施者により厳重に管理され，研究目的以外には使用致しません。</u><br>
          実験結果は<u>国内外の学会や論文で発表，</u>することがありますが，データは統計的な処理などを行いますので，個人がデータから特定されることはありません。<br>
          また匿名化処理されたデータは，<u>研究発表に伴い公開される</u>ことがあります。
      <br>
      <br>
      <b><li>参加と中止について</li></b>
          本実験へのご参加はあなたの自由意思に基づいて決定して下さい。<br>
          <u>実験参加への同意はいつでも取り消すことができ，それによる不利益はありません。</u>
          参加に同意した後に参加途中で撤回したい場合，そのままブラウザを閉じていただけると同意撤回したものとみなします。<br>
          参加途中で参加を撤回された場合は，そのデータをその後の研究で使用いたしません。
      <br>
      <br>
      </div>
      `
    ];


const informedConsent = {
  type: 'survey-multi-select',
  questions: [{
      prompt: '<b>上記事項をよく読み，理解した上で実験参加に同意いただける方はチェックをお願いします。同意されない方はブラウザを閉じてください。</b></span>', //font-size: 2vhをタグに入れると相対フォントサイズ
      options: ['説明事項をよく読み，理解した上で，実験参加に同意します。</span>'],
      required: true,
      name: 'approval',
      }],
      preamble: informedConsentText,
      button_label: '次へ',
      required_message: '実験参加に同意する場合，必ずこのチェックボックスをクリックしてから進んでください。'
    };

timeline.push(informedConsent);

const age = {
	type: 'survey-text',
	questions: [{
		　prompt: `
		　     <p>あなたの年齢はいくつですか？</p>
	         		 <p>半角数字で入力してください。</p>`,
			rows: 1,
			columns: 2,
			required: true,
			name: 'age'
			}],
	button_label: '次へ',
	on_finish: function(data){
			jsPsych.data.addProperties({ID: myrandID})
			const participants_age = JSON.parse(data.responses); // responsesは集計時に扱いにくいため、parseしておくと便利です。
			jsPsych.data.addProperties(participants_age);
	}
};

timeline.push(age);

// 人口統計データの質問
const genderValues = [
	'男性',
  '女性',
  '回答しない'
];
const Handedness = [
	'右利き',
  '左利き'
];

const license = [ // この変数名を変更しないでください。私が書いたコードでアクセスしています。
	'所有している',
  '所有していない'
];






// 実験終了の教示と作業コードのお知らせ
const ending = {
	type: "html-button-response",
  choices: ['閉じる'],
	stimulus: `<p style = "font-size: 2vh;">全ての試行が終わりました。今回の作業完了コードは<strong>「0000」</strong>です。</p>
						 <p style = "font-size: 2vh;">この4桁の数字を，Yahoo!クラウドソーシングの設問への回答として<u>半角で</u>入力して下さい。</p>
						 <p style = "font-size: 2vh;">この数字の入力は1度しかできないため，間違えないようにしてください。</p>
						 <p style = "font-size: 2vh;">[閉じる]ボタンを押すと実験完了となります。</p>
						 <p style = "font-size: 2vh;">ありがとうございました。</p>`,
};
const questions = {
    type: 'survey-multi-choice',
    questions: [
      {prompt: 'あなたが自認する性別は？', options: genderValues, required: true, horizontal: true, name:'sex'},
      {prompt: 'あなたの利き手は？', options: Handedness, required: true, horizontal: true, name:'handedness'},
      {prompt: 'ダイビングライセンス(Cカード)を所有していますか？', options: license, required: true, horizontal: true, name: 'license_choice'}, // nameを付け加えています。nameの内容（license_choice）を変更すると適切に動作しなくなるので注意してください。
		],
    button_label: '次へ',
    on_finish: function(data){
			jsPsych.data.addProperties({ID: myrandID})
      jsPsych.pauseExperiment();
      const responses_array = JSON.parse(data.responses);
			jsPsych.data.addProperties(responses_array)

      let timeline2;
      if (responses_array.license_choice === license[0]) {
        timeline2 = [post_questions, Word_Evalution_Inst, Word_evaluate, IntroWAT, WATtask,ending] // ライセンスを持っているので追加質問あり
      } else {
        timeline2 = [Word_Evalution_Inst, Word_evaluate, IntroWAT, WATtask,ending] // ライセンスを持っていないので追加質問なし
      }
      // 最初の段階で timelineにすべてを登録しないことがポイントです。
      // ライセンスの所有を確認してから、その後の手続をtimelineに登録します
      jsPsych.addNodeToEndOfTimeline({ // https://www.jspsych.org/core_library/jspsych-core/#jspsychaddnodetoendoftimeline
        timeline: timeline2,
      }, jsPsych.resumeExperiment)
    }

};
timeline.push(questions);

// ライセンスを持っている人だけへの追加の質問
const post_questions = {
  type: 'survey-text',
	questions: [{
		　prompt: `<p>あなたがこれまで経験したダイビング本数はいくつですか？</p>
							<p>半角数字で入力してください。</p>`,
			rows: 1,
			columns: 4,
			required: true,
			name: 'dive_num'
			}],
    button_label:'次へ',
    on_finish: function(data){
        const dive_num = JSON.parse(data.responses); // responsesは集計時に扱いにくいため、parseしておくと便利です。
        jsPsych.data.addProperties(dive_num);
    }
}
const Word_Evalution_Inst = {
  type: 'html-button-response',
  choices: ['回答へ進む'],
  stimulus:
    // ここではテンプレートリテラルというのを使っています。慣れると便利ですよ。
    // https://qiita.com/kura07/items/c9fa858870ad56dfec12
    // テンプレートリテラルでは + は使わないので注意ください。
    // <div style='width:500px' ></div>

    `
    <p style = "font-size: 2vh;">これから「楽しい」・「驚き」・「悲しい」について評定してもらいます。</p>
    <p style = "font-size: 2vh;">評定は，具体性・想像性・文脈利用可能性・感情価の4つの観点から評定をしてもらいます。</p>
    <p style = "font-size: 2vh;">単語の下に表示されるスライダーを左右のどちらかにドラッグで動かして自分の考えに近いと思う方に評価してください。</p>
    `,
  on_finish: function(data){
  if (!data.dive_num){
      jsPsych.data.addProperties({dive_num: ''})
    }
  }
};


const Wordlist =
            [{word:'楽しい'},
             {word:'驚き'},
             {word:'悲しい'},
             ];

jsPsych.randomization.shuffle(Wordlist);
var Word_evaluate = {
    timeline_variables: Wordlist,
    timeline:[
        {
            type: 'html-slider-response',
            data: { // dataプロパティを使いこなせるようになると便利です。詳しくは、https://www.jspsych.org/tutorials/rt-task/#part-9-tagging-trials-with-additional-data
                block: 'concreteness',
                expression: jsPsych.timelineVariable('word')
            },
            // stimulus:jsPsych.timelineVariable('word'),
            stimulus: jsPsych.timelineVariable('word'),
            labels: ['非常に抽象的', '非常に具体的'],
            button_label:'次へ',
            prompt:'単語についてあなたが持つ印象を表すのに最もふさわしい位置に<br>ツマミをスライドさせてお答え下さい<br><br>',
            require_movement:true
        },

        {
            type: 'html-slider-response',
            data: { // dataプロパティを使いこなせるようになると便利です。詳しくは、https://www.jspsych.org/tutorials/rt-task/#part-9-tagging-trials-with-additional-data
                block: 'imageability',
                expression: jsPsych.timelineVariable('word')
            },
            stimulus:jsPsych.timelineVariable('word'),
            labels: ['想像し難い', '想像しやすい'],
            button_label:'次へ',
            prompt:'単語についてあなたが持つ印象を表すのに最もふさわしい位置に<br>ツマミをスライドさせてお答え下さい<br><br>',
            require_movement:true
        },

        {
            type: 'html-slider-response',
            data: { // dataプロパティを使いこなせるようになると便利です。詳しくは、https://www.jspsych.org/tutorials/rt-task/#part-9-tagging-trials-with-additional-data
                block: 'context availability',
                expression: jsPsych.timelineVariable('word')
            },
            stimulus:jsPsych.timelineVariable('word'),
            labels: ['文脈を考えづらい', '文脈を考えやすい'],
            prompt:'単語についてあなたが持つ印象を表すのに最もふさわしい位置に<br>ツマミをスライドさせてお答え下さい<br><br>',
            button_label:'次へ',
            require_movement:true
        },

        {
            type: 'html-slider-response',
            data: {},
            //  preambleはひとつの試行でひとつだけ設定できて、questionsは複数設定できます。
            data: { // dataプロパティを使いこなせるようになると便利です。詳しくは、https://www.jspsych.org/tutorials/rt-task/#part-9-tagging-trials-with-additional-data
                block: 'valence',
                expression: jsPsych.timelineVariable('word')
            },
            stimulus:jsPsych.timelineVariable('word'),
            labels: ['非常にネガティブ', '非常にポジティブ'],
            prompt:'単語についてあなたが持つ印象を表すのに最もふさわしい位置に<br>ツマミをスライドさせてお答え下さい<br><br>',
            button_label:'次へ',
            require_movement:true
        }
    ],
    randomize_order: true,
    repetitions: 1
};
// const symbols = [
//   {mark: '●', label: 'circle'},
//   {mark: '■', label: 'rectangle'},
//   {mark: '▲', label: 'triangle'}];
const symbols = [
  {mark: 'circle.png', label: 'circle'},
  {mark: 'rectangle.png', label: 'rectangle'},
  {mark: 'triangle.png', label: 'triangle'}];

const shuffled_symbols = jsPsych.randomization.shuffle(symbols); // https://www.jspsych.org/core_library/jspsych-randomization/#jspsychrandomizationshuffle

shuffled_symbols.push({mark: 'star.png', label: 'star'})

// 「楽しい」「驚き」「悲しい」の順番は固定なので注意してください。
shuffled_symbols[0].meaning_JP = '楽しい';
shuffled_symbols[0].meaning_EN = 'happy';
shuffled_symbols[1].meaning_JP = '驚き';
shuffled_symbols[1].meaning_EN = 'surprise';
shuffled_symbols[2].meaning_JP = '悲しい';
shuffled_symbols[2].meaning_EN = 'sad';
shuffled_symbols[3].meaning_JP = '確認';
shuffled_symbols[3].meaning_EN = 'check';


console.log(shuffled_symbols) // コンソールで確認

// WAT課題の開始
// 教示文
const IntroWAT = {
  type: 'html-button-response',
  choices: ['回答へ進む'],
  stimulus:
    // ここではテンプレートリテラルというのを使っています。慣れると便利ですよ。
    // https://qiita.com/kura07/items/c9fa858870ad56dfec12
    // テンプレートリテラルでは + は使わないので注意ください。
    `<div style = "color: black;"><p style = "font-size: 2vh;">これから四角の枠内に
    <img src='${shuffled_symbols[0].mark}' alt='' style="width:24px;height:24px;vertical-align:middle;"><span style="vertical-align:middle;">・</span>
    <img src='${shuffled_symbols[1].mark}' alt='' style="width:24px;height:24px;vertical-align:middle;"><span style="vertical-align:middle;">・</span>
    <img src='${shuffled_symbols[2].mark}' alt='' style="width:24px;height:24px;vertical-align:middle;"><span style="vertical-align:middle;"></span>
    の図形が呈示されます。</p>
    <p style = "font-size: 2vh;">それらの図形が，「${shuffled_symbols[0].meaning_JP}」，「${shuffled_symbols[1].meaning_JP}」，「${shuffled_symbols[2].meaning_JP}」のいずれかを表しています。</p>
    <p style = "font-size: 2vh;">その場合，それぞれの図形をあなたならどこに置きますか？</p>
    <p style = "font-size: 2vh;">それらの図形をドラッグして枠内の任意の位置に置いてください</p>
    <p style = "font-size: 2vh;"><br>準備ができたら「回答へ進む」を押して回答を始めてください。</p></div>`,
  on_finish: function(data){
  if (!data.dive_num){
      jsPsych.data.addProperties({dive_num: ''})
    }
  }
};

var WATtask = {
  type: 'free-sort-touch',
  stimuli: [
    'triangle.png',
    'rectangle.png',
    'circle.png',
    'star.png'
  ],
  stim_height: 30, // 丸や四角のサイズ
  stim_width: 30,
  sort_area_height: 500,
  sort_area_width	: 500,
  prompt:`　
  <div align='left' style='width:500px' >
        <p style = "font-size: 2vh;">以下のように単語が割り当てられた図形を任意の位置に図形を配置してください。</p>
        <p style = "font-size: 2vh;">重なった位置に図形を置いても構いません。</p>
        <p style = "font-size: 2vh;">ただし，
        <img src='${shuffled_symbols[3].mark}' alt='' style="width:24px;height:24px;vertical-align:middle;"><span style="vertical-align:middle;">は必ず<b>枠の一番右下の角</b>に配置してください。</p>

        <p style = "font-size: 2vh;"><img src='${shuffled_symbols[0].mark}' alt='' style="width:24px;height:24px;vertical-align:middle;"><span style="vertical-align:middle;">　＝　 ${shuffled_symbols[0].meaning_JP}</p></span>
        <p style = "font-size: 2vh;"><img src='${shuffled_symbols[1].mark}' alt='' style="width:24px;height:24px;vertical-align:middle;"><span style="vertical-align:middle;">　＝　 ${shuffled_symbols[1].meaning_JP}</p></span></p>
        <p style = "font-size: 2vh;"><img src='${shuffled_symbols[2].mark}' alt='' style="width:24px;height:24px;vertical-align:middle;"><span style="vertical-align:middle;">　＝　 ${shuffled_symbols[2].meaning_JP}</p></span></p>
  </div>
        `,
  button_label: '決定',
  on_finish: function(data){

    // マークの意味を記録する
    const symbols_output = {}
    for (let i = 0; i < shuffled_symbols.length; i++){
      const meaning = shuffled_symbols[i].meaning_JP
      symbols_output[meaning] = shuffled_symbols[i].label
    }
    jsPsych.data.addProperties(symbols_output)

    // 基本的に必要なデータは自動で保存されるのですが、そのままだと分析がしにくいと思い、以下のようなものを考えました。
    // あまりうまいやりかたではないかもしれませんが・・・
    // とりあえず、final_locations　が重要だろうと思って、それを分析しやすく出力しています。
    // 出力データの詳細は、https://www.jspsych.org/plugins/jspsych-free-sort/
    // データを確認すると、final_locationsが、JSON string であることが分かります。

    // JSON stringのときは、とりあえず、JSON.parseすると覚えておくとよいと思います。
    const final_locations_array = JSON.parse(data.final_locations);

    for (let i = 0; i < final_locations_array.length; i++){
      console.log(final_locations_array[i])

      const file_name = final_locations_array[i].src; // 画像の名前

      // 画像の名前から、意味を見つけ出す
      for (let j = 0; j < shuffled_symbols.length; j++){
        if (file_name.indexOf(shuffled_symbols[j].label) !== -1){
          const label_x = shuffled_symbols[j].meaning_EN + '_x';
          const label_y = shuffled_symbols[j].meaning_EN + '_y';
          const coordinate = {} // 出力したい座標を保存するためのオブジェクト
          coordinate[label_x] = final_locations_array[i].x;
          coordinate[label_y] = final_locations_array[i].y;

          jsPsych.data.addProperties(coordinate)
          break;
        }
      }
    }
  }
};


// 実験の実行
jsPsych.init({
  timeline: timeline,
  // timeline: [timeline, timeline2],
  on_finish: function(){
    // saveData();
    // jsPsych.data.displayData();}
    // 文字化けをするデータを削除して保存
    // let output_data = jsPsych.data.get().ignore('stimulus');
    // jsPsych.data.get().ignore('stimulus');
    // output_data = output_data.ignore('string');
    // output_data = output_data.ignore('color');
    // output_data.localSave('csv', myrandID + '.csv');
		close(); //close the tab.
  }
});
